import Implementacion.ConjuntoEstatico;
import Interface.ConjuntoTDA;

public class Main {
    public static void main(String[] args) {

        ConjuntoTDA legajos = new ConjuntoEstatico();
        legajos.InicializarConjunto();

        // Un legajo identifica al alumno y, por lo tanto,
        // no puede repetirse aunque el alumno se inscriba
        // en más de una carrera.
        legajos.Agregar(1001);
        legajos.Agregar(1002);
        legajos.Agregar(1001); // No se agrega nuevamente.

        System.out.println("¿Legajo 1001 pertenece?: " + legajos.Pertenece(1001));
        System.out.println("¿Legajo 1003 pertenece?: " + legajos.Pertenece(1003));

        // Un mismo alumno puede anotarse a dos carreras sin duplicar
        // su legajo: se reutiliza el mismo identificador del alumno.
        System.out.println("Legajos registrados: 1001, 1002");
        System.out.println("El alumno 1001 puede estar en dos carreras con el mismo legajo.");

        // Elegir no tiene que devolver un elemento aleatorio.
        // Como el conjunto no cambia entre ambas llamadas, puede
        // devolver exactamente el mismo elemento.
        int primero = legajos.Elegir();
        int segundo = legajos.Elegir();

        System.out.println("Primera llamada a Elegir: " + primero);
        System.out.println("Segunda llamada a Elegir: " + segundo);
        System.out.println("¿Puede devolver el mismo elemento?: " + (primero == segundo));

        legajos.Sacar(1001);

        System.out.println("¿Legajo 1001 pertenece luego de Sacar?: "
                + legajos.Pertenece(1001));
        System.out.println("¿Conjunto vacío?: " + legajos.ConjuntoVacio());
    }
}
